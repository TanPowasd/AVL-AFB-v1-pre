"""Training and market models derived from the public Frontier Lab rules."""

import math
from collections import defaultdict
from functools import lru_cache


DOMAINS = ("web", "code", "math", "books", "science", "dialog", "multiling")
POOLS = (*DOMAINS, "synth", "distill")
SPECIAL = {(2, 1): (0.40, 0.70), (5, 6): (0.30, 0.60), (4, 3): (0.30, 0.50),
           (5, 0): (0.20, 0.40), (2, 4): (0.20, 0.40), (1, 0): (0.10, 0.25)}
TASKS = ((2,), (1,), (4, 3), (5,), (6,), (0,))
PROBE_N = 0.025
PROBE_MIX = dict.fromkeys(DOMAINS, 1 / 7)
LOW_RATE = 0.00040
SAFE_RATE = 0.00120


def clip(x, low, high):
    return min(high, max(low, x))


def retained(n, interval, mtbf=50000.0, cost=0.2, restart=2, interrupt=0.0):
    p = 1 - (1 - n / mtbf) * (1 - interrupt)
    if p >= 1:
        return 0.0
    if p <= 0:
        return 1 - cost / interval
    log_q = math.log1p(-p)
    return p * math.exp((restart + interval) * log_q) * (interval - cost) / -math.expm1(interval * log_q)


@lru_cache(maxsize=8192)
def checkpoint(n, mtbf=50000.0, cost=0.2, restart=2, interrupt=0.0):
    if not n:
        return 24, 1.0
    rate = 1 - (1 - n / mtbf) * (1 - interrupt)
    if rate >= 1:
        return 1, 0.0
    decay = -math.log1p(-rate)
    # The sign of the derivative of (k - cost) / expm1(decay * k)
    # decreases strictly for k >= 1. Find the two bracketing integers.
    low, high = 1, 1 + max(1, math.ceil(4 * math.sqrt(cost / rate)))
    while -math.expm1(-decay * high) > decay * (high - cost):
        high *= 2
    while high - low > 1:
        mid = (low + high) // 2
        if -math.expm1(-decay * mid) > decay * (mid - cost):
            low = mid
        else:
            high = mid
    a = retained(n, low, mtbf, cost, restart, interrupt)
    b = retained(n, high, mtbf, cost, restart, interrupt)
    return (low, a) if a >= b else (high, b)


def market_price(strength, rivals, cost, displaced, max_share=1.0, ceiling=100.0):
    """Maximize (price - cost + displaced) times the equilibrium share."""
    ratio = max(1e-12, rivals / strength)
    low, high = 1.0, ceiling
    for _ in range(22):
        p = (low + high) / 2
        z = ratio * p ** 1.5
        if p * (1 - 0.5 * z) > 1.5 * z * (displaced - cost):
            low = p
        else:
            high = p
    if max_share < 1.0:
        min_price = ((1 / max(1e-4, max_share) - 1) / ratio) ** (2 / 3)
        low = max(low, min_price)
    return clip(low, 1.0, ceiling)


def effective(tokens, width):
    return -width * math.expm1(-tokens / width) if width > 0 else 0.0


class Scaling:
    def __init__(self, init):
        public = {x["name"]: x for x in init["domains"]}
        self.size0 = [public[p]["public_b"] for p in POOLS[:-1]] + [0.0]
        self.q0 = [clip(public[p]["q_hint"], 0.54, 1.46) for p in POOLS[:-1]] + [0.0]
        self.q0[7] = clip(self.q0[7], 0.62, 0.88)
        self.c0 = [0.06] * 7 + [0.0, 0.0]
        self.size = self.size0.copy()
        self.q = self.q0.copy()
        self.c = self.c0.copy()
        self.extra = [0.0] * 9
        self.quality = [0.0] * 9
        self.dirt = [0.0] * 9
        self.filtered = set()
        self.known_q = set()
        self.alpha = 0.34
        self.beta = 0.30
        self.a = 0.45
        self.b = 1.20
        self.floor = [1.8] * 7
        self.eta = SAFE_RATE
        self.bc = 380.0
        self.bc_samples = 0
        self.diag = []
        self.ready = False
        self.links = [[1.0 if i == j else 0.325 if j == 7 else 0.5 if j == 8
                       else sum(SPECIAL.get((i, j), (0.02, 0.12))) / 2
                       for j in range(9)] for i in range(7)]
        self.weights = []
        for focus in TASKS:
            w = [0.475 / (7 - len(focus))] * 7
            for k, d in enumerate(focus):
                w[d] = 0.525 * (1.0 if len(focus) == 1 else (0.6, 0.4)[k])
            self.weights.append(w)
        self.reference()

    def probes(self):
        specs = []
        for i in range(10):
            specs.extend((("lr", i, PROBE_N, 6.0, c, PROBE_MIX) for c in (LOW_RATE, SAFE_RATE)))
        for n in (PROBE_N, 0.125, 0.625, 3.125):
            specs.extend(("n", None, n, 6.0, SAFE_RATE, PROBE_MIX) for _ in range(3))
        for j, domain in enumerate(DOMAINS):
            for d in (1.2, 11.0, 90.0):
                specs.extend(("d", j, PROBE_N, d, SAFE_RATE, {domain: 1.0}) for _ in range(2))
        return specs

    def observe_batch(self, n, batch, d, eff):
        if batch <= 0 or n <= 0:
            return
        w = eff / min(1.0, 2 * batch / n)
        if 0.502 < w < 0.999:
            estimate = batch * (2 * w - 1) / (1 + d / 50) ** 0.4
            if 190 < estimate < 650:
                weight = 1 / min(15, 1 + self.bc_samples)
                self.bc += weight * (estimate - self.bc)
                self.bc_samples += 1

    def calibrate(self, observations):
        eta_samples = defaultdict(list)
        size_samples = []
        data_samples = defaultdict(list)
        for (kind, index, n, d, lr, _), losses in observations:
            if kind == "lr":
                eta_samples[lr].append(sum(losses) / len(losses))
            elif kind == "n":
                size_samples.append((n, sum(losses) / len(losses)))
            else:
                width = 4 * self.size0[index]
                data_samples[index].append((effective(d, width), losses))
        if eta_samples[LOW_RATE] and eta_samples[SAFE_RATE]:
            low, high = (sum(eta_samples[r]) / len(eta_samples[r]) for r in (LOW_RATE, SAFE_RATE))
            log_eta = (low - high) / (0.16 * math.log(SAFE_RATE / LOW_RATE))
            log_eta += (math.log(SAFE_RATE) + math.log(LOW_RATE)) / 2
            self.eta = clip(math.exp(log_eta - 0.070), SAFE_RATE, 0.00277)
        if len(size_samples) >= 8:
            def fit_size(alpha):
                x = [n ** -alpha for n, _ in size_samples]
                y = [v for _, v in size_samples]
                xm, ym = sum(x) / len(x), sum(y) / len(y)
                a = sum((u - xm) * (v - ym) for u, v in zip(x, y)) / sum((u - xm) ** 2 for u in x)
                a = clip(a, 0.30, 0.60)
                err = sum((v - ym - a * (u - xm)) ** 2 for u, v in zip(x, y))
                return err + 0.045 * (alpha - 0.34) ** 2, alpha, a

            _, self.alpha, self.a = min(fit_size(0.28 + 0.005 * j) for j in range(25))
        if len(data_samples) == 7 and min(map(len, data_samples.values())) >= 3:
            def fit_data(beta):
                groups = [(j, [(x ** -beta, y) for x, y in rows]) for j, rows in data_samples.items()]
                groups = [(j, rows, sum(x for x, _ in rows), sum(x * x for x, _ in rows))
                          for j, rows in groups]
                base_den = sum(len(rows) - sum_x * sum_x / square for _, rows, sum_x, square in groups)
                mids = []
                slopes = [[0.0] * 7 for _ in range(7)]
                error = 0.0
                for i in range(7):
                    xys = [sum(x * y[i] for x, y in rows) for _, rows, _, _ in groups]
                    base = sum(sum(y[i] for _, y in rows) - sum_x * xy / square
                               for (_, rows, sum_x, square), xy in zip(groups, xys)) / base_den
                    mids.append(base)
                    for (j, rows, sum_x, square), xy in zip(groups, xys):
                        slope = max(0.1, (xy - base * sum_x) / square)
                        slopes[i][j] = slope
                        error += sum((base + slope * x - y[i]) ** 2 for x, y in rows)
                return error + 0.3 * (beta - 0.30) ** 2, beta, mids, slopes

            _, self.beta, mids, slopes = min(fit_data(0.25 + 0.005 * j) for j in range(21))
            penalty = 0.08 * math.log(SAFE_RATE / self.eta) ** 2
            self.floor = [clip(x - self.a * PROBE_N ** -self.alpha - penalty, 1.4, 2.2) for x in mids]
            self.diag = [slopes[j][j] for j in range(7)]
            for i in range(7):
                for j in range(7):
                    if i != j:
                        lo, hi = SPECIAL.get((i, j), (0.02, 0.12))
                        estimate = (slopes[j][j] / slopes[i][j]) ** (1 / self.beta)
                        self.links[i][j] = clip(0.88 * estimate + 0.12 * (lo + hi) / 2, lo, hi)
        self.ready = True
        self.reference()

    def refresh(self, j):
        u = self.size0[j] + self.extra[j]
        if u:
            self.size[j] = u
            self.q[j] = (self.q0[j] * self.size0[j] + self.quality[j]) / u
            self.c[j] = (self.c0[j] * self.size0[j] + self.dirt[j]) / u * (0.5 if j in self.filtered else 1.0)

    def add(self, j, amount, quality, pollution=0.0):
        if amount > 0:
            self.extra[j] += amount
            self.quality[j] += amount * quality
            self.dirt[j] += amount * pollution
            self.refresh(j)

    def filter(self, domain, quality, pollution):
        j = POOLS.index(domain)
        self.filtered.add(j)
        self.known_q.add(j)
        self.q0[j] = quality
        self.c0[j] = 2 * pollution
        self.refresh(j)
        self.reference()

    def reference(self):
        if self.diag:
            vals = [(slope * max(0.1, q) ** self.beta, 3 if j in self.known_q else 1)
                    for j, (slope, q) in enumerate(zip(self.diag, self.q0))]
            self.b = clip(sum(v * n for v, n in vals) / sum(n for _, n in vals), 0.90, 1.50)
        small = self.loss(20, [400 / 7] * 7 + [0, 0], self.size0, self.q0, 0)
        large = self.loss(300, [6000 / 7] * 7 + [0, 0], self.size0, self.q0, 0)
        lo = math.log(0.2 / 0.8)
        hi = math.log(0.85 / 0.15)
        self.tasks = []
        for w in self.weights:
            s = sum(v * x for v, x in zip(w, small))
            l = sum(v * x for v, x in zip(w, large))
            scale = (s - l) / (hi - lo)
            self.tasks.append((w, s + lo * scale, scale))
        self.importance = [sum(w[j] / scale for w, _, scale in self.tasks) for j in range(7)]

    def loss(self, n, counts, size, quality, anneal, loss_penalty=0.0):
        base = self.a / n ** self.alpha + loss_penalty
        e = [effective(x, 4 * u) * q for x, u, q in zip(counts, size, quality)]
        return [(f + base + self.b * max(0.01, sum(a * b for a, b in zip(row, e))) ** -self.beta)
                * (1 - anneal) for f, row in zip(self.floor, self.links)]

    def score(self, n, counts, anneal=0.03, penalty=0.0005):
        loss = self.loss(n, counts, self.size, self.q, anneal, penalty)
        return sum(1 / (1 + math.exp(-clip((tau - sum(v * x for v, x in zip(w, loss))) / scale, -40, 40)))
                   for w, tau, scale in self.tasks) / len(self.tasks)

    def mix(self, tokens, consumed=None):
        # Convex loss surrogate on token counts. Pairwise exchange preserves the
        # simplex, the copyright budget and the two synthetic-data limits.
        consumed = consumed or [0.0] * 9
        remaining = max(0.0, tokens - sum(consumed))
        width = [4 * u if u > 0 else 1.0 for u in self.size]
        room = [remaining] * 7 + [0.298 * remaining if self.size[7] else 0.0,
                                 0.096 * remaining if self.size[8] else 0.0]
        caps = [p + r for p, r in zip(consumed, room)]
        counts = [n + remaining / 7 if j < 7 else n for j, n in enumerate(consumed)]
        columns = list(zip(*self.links))
        protected = (0, 3)
        dirty_target = 0.046 * tokens
        for _ in range(24):
            exp = [math.exp(-d / u) for d, u in zip(counts, width)]
            e = [(1 - a) * u * q for a, u, q in zip(exp, width, self.q)]
            v = [max(0.01, sum(x * y for x, y in zip(row, e))) for row in self.links]
            dirt = sum(x * c for x, c in zip(counts, self.c))
            grad = [w * (x ** (-self.beta - 1)) for w, x in zip(self.importance, v)]
            # Above the audit threshold, additional pollution has a real
            # future cost. Its quadratic penalty keeps the surrogate convex.
            dirty_scale = 8.0 / max(1.0, tokens * tokens)
            p = dirty_scale * max(0.0, dirt - dirty_target)
            merit = [self.beta * self.b * a * q * sum(x * y for x, y in zip(col, grad)) - p * c
                     for a, q, c, col in zip(exp, self.q, self.c, columns)]
            group_space = consumed[0] + consumed[3] + 0.498 * remaining - counts[0] - counts[3]
            best = (0.0, 0, 0, 0.0)
            for i in range(9):
                if caps[i] - counts[i] < 1e-7:
                    continue
                for j in range(9):
                    if j == i or counts[j] - consumed[j] < 1e-7:
                        continue
                    gap = merit[i] - merit[j]
                    if gap <= best[0]:
                        continue
                    transfer = min(caps[i] - counts[i], counts[j] - consumed[j])
                    if i in protected and j not in protected:
                        transfer = min(transfer, group_space)
                    if transfer > 1e-7:
                        best = gap, i, j, transfer
            gap, i, j, right = best
            if gap * tokens < 2e-5:
                break
            left = 0.0
            delta_c = self.c[i] - self.c[j]
            for _ in range(8):
                step = (left + right) / 2
                a = self.q[i] * exp[i] * math.exp(-step / width[i])
                de_i = self.q[i] * exp[i] * effective(step, width[i])
                if step / width[j] < 500:
                    b = self.q[j] * exp[j] * math.exp(step / width[j])
                    de_j = -self.q[j] * exp[j] * width[j] * math.expm1(step / width[j])
                else:
                    b = self.q[j] * math.exp(-(counts[j] - step) / width[j])
                    de_j = width[j] * (self.q[j] * exp[j] - b)
                slope = sum(w * (x * a - y * b) * max(0.01, s + x * de_i + y * de_j) ** (-self.beta - 1)
                            for w, x, y, s in zip(self.importance, columns[i], columns[j], v))
                slope *= self.beta * self.b
                slope -= dirty_scale * delta_c * max(0.0, dirt + step * delta_c - dirty_target)
                if slope > 0:
                    left = step
                else:
                    right = step
            step = (left + right) / 2
            counts[i] += step
            counts[j] -= step
        return counts
