"""Frontier Lab strategy using only the public JSON protocol."""

import json
import math
import sys
from bisect import bisect_right
from collections import deque

from frontier_math import DOMAINS, POOLS, Scaling, checkpoint, clip, effective, market_price


DEADLINES = (1470, 4520, 8150, 12480, 16950, 23300, 26145)
LEASE_MILESTONES = (1470, 4700, 8650, 12850, 17400, 22200, 26145)
RESEARCH = ("algo_eff_1", "filter:code", "filter:multiling", "infer_opt_1", "filter:math",
            "infer_opt_2", "algo_eff_2", "cooling", "early_supply", "curriculum", "algo_eff_3",
            "filter:dialog", "filter:science", "filter:web", "filter:books", "synth", "stable")
OWN_TARGET = (2280, 4850, 8100, 9200, 5150)
LAST_BUY = (2900, 10500, 17000, 24800, 25000)
TRAIN_FLOOR = (2650, 6300, 14800, 23900, 36500, 54000, 75000)
MAX_LEASE_RATE = (0.041, 0.024, 0.034, 0.045, 0.055, 0.057, 0.018)
MARKET_FEEDBACK = True
CONTINUOUS_TRAINING = True
BOOTSTRAP_SYNTH = True
ADAPT_AUCTIONS = True
FINANCE = False
SPOT_TRAINING = True
SPOT_HEADROOM = 1.34
DATA_VALUE = True


def add(action, field, value):
    action.setdefault(field, []).append(value)


def utility(pub, price):
    return 6 * pub - 1.5 * math.log(max(1.0, price))


class Frontier:
    def __init__(self, init):
        self.rules = init["rules"]
        self.gpus = init["gpus"]
        self.names = [g["model"] for g in self.gpus]
        self.power = [g["power"] for g in self.gpus]
        self.regions = init["regions"]
        self.label = "AB"[init["seat"]]
        self.rival = "BA"[init["seat"]]
        self.ticks = init["ticks"]
        self.end = self.ticks - self.rules["LAUNCH"] - self.rules["MIN_ONLINE_END"] - 3
        self.deadlines = [d for d in DEADLINES if d < self.end - 400]
        self.deadlines.append(min(self.end, DEADLINES[-1]))
        self.scale = Scaling(init)
        self.queue = deque(self.scale.probes())
        self.probes = {}
        self.samples = []
        self.probe_active = None
        self.tech = set()
        order = list(RESEARCH)
        if BOOTSTRAP_SYNTH:
            order.remove("synth")
            order.insert(2, "synth")
        self.research_order = order
        self.staff = []
        self.researching = None
        self.sites = []
        self.deliveries = []
        self.rent_prices = {}
        self.rival_cloud = {}
        self.contracts = {}
        self.public_deals = []
        self.synth_inflight = []
        self.seed_checkpoint = None
        self.seed_sent = False
        self.corpus_sent = False
        self.lease_ids = []
        self.lease_until = -1
        self.spot_generation = None
        self.spot_cut = False
        self.raised = set()
        self.models = {m["id"]: dict(m) for m in init["models"]}
        self.last_price = {}
        self.pending_release = None
        self.publishing = None
        self.reputation = 0.0
        self.product = None
        self.share = {}
        self.rival_effect = 0.0
        self.rival_id = None
        self.observed_price = None
        self.market_q = 5.0
        self.heat = 1.0
        self.week = None
        self.auction_bid = {}
        self.auction_need = [1.50, 1.50, 1.62, 1.62, 1.62]
        self.phase = 0
        self.run = None
        self.opened = False
        self.revenue = 0.0
        self.trailing = deque()
        self.trailing_sum = 0.0
        self.stats = {}

    def ingest_week(self, wk, tick):
        previous_heat = self.heat
        self.week = wk
        self.heat = wk["heat"]
        self.market_q = wk["demand"]
        self.share = wk["shares"]
        if ADAPT_AUCTIONS:
            for model, sale in wk["auction"].items():
                if model not in self.auction_bid:
                    continue
                i = self.names.index(model)
                ratio, lots = self.auction_bid[model]
                cutoff = sale["clear"] / (self.gpus[i]["price"] * previous_heat)
                won = sale["winners"].get(self.label, 0)
                if won < lots and len(sale["winners"]) > 0:
                    self.auction_need[i] = min(2.90, max(self.auction_need[i], ratio * 1.14, cutoff * 1.11))
                elif won:
                    self.auction_need[i] = max(1.52, 0.92 * self.auction_need[i], cutoff * 1.10)
            self.auction_bid.clear()
        my = wk["my"]
        self.tech.update(my["tech"])
        self.staff = my["staff"]
        self.sites = my["sites"]
        self.deliveries = my["deliv"]
        self.models = {m["id"]: dict(m) for m in wk["models"]}
        if MARKET_FEEDBACK:
            leaders, weights = self.rivals(adjust=False)
            rival = leaders.get(self.rival)
            if rival:
                _, m = rival
                outside = sum(w for lab, w in weights.items() if lab != self.rival)
                outside_share = sum(v for lab, v in self.share.items() if lab not in (self.label, self.rival))
                their_share = self.share.get(self.rival, 0.0)
                if outside_share > 0.025:
                    ratio = ((their_share + 0.001) * outside / outside_share) / weights[self.rival]
                    observed = math.log(clip(ratio, 0.0015, 1.03))
                    changed = (self.rival_id != m["id"] or self.observed_price is None
                               or abs(math.log(max(1, m["price"]) / max(1, self.observed_price))) > 0.16)
                    weight = 0.66 if not changed else 0.39
                    self.rival_effect = (1 - weight) * self.rival_effect + weight * observed
                self.rival_id, self.observed_price = m["id"], m["price"]
            else:
                self.rival_effect, self.rival_id, self.observed_price = 0.0, None, None
        for result in wk["deal_results"]:
            deal = self.contracts.get(result["deal"])
            if not deal:
                continue
            j = POOLS.index(deal["domain"])
            quality = clip(deal["q_hint"], 0.63, 1.47)
            if result["winner"] == self.label:
                self.scale.add(j, deal["tokens_b"], quality, 0.04)
            elif result["winner"] == self.rival:
                self.public_deals.append((tick + self.rules["EXCL_TICKS"], j, deal["tokens_b"], quality))
        next_deals = []
        for ready, j, amount, quality in self.public_deals:
            if ready <= tick:
                self.scale.add(j, amount, quality, 0.04)
            else:
                next_deals.append((ready, j, amount, quality))
        self.public_deals = next_deals
        self.contracts = {d["id"]: d for d in wk["deals"]}
        for j, name in enumerate(POOLS):
            delta = my["data"].get(name, 0.0) - self.scale.size[j]
            if delta > 0.05:
                self.scale.add(j, delta, 0.95, 0.04 if j < 7 else 0.0)

    def observe(self, o):
        tick = o["t"]
        self.reputation = o["rep"]
        self.spot_cut = False
        self.revenue += (o["api"][2] - self.revenue) / 168
        rev = o["api"][2]
        self.trailing.append(rev)
        self.trailing_sum += rev
        if len(self.trailing) > self.rules["GM_WINDOW"]:
            self.trailing_sum -= self.trailing.popleft()
        credited = []
        for ready, amount, quality in self.synth_inflight:
            if tick >= ready:
                self.scale.add(7, amount, quality)
            else:
                credited.append((ready, amount, quality))
        self.synth_inflight = credited
        if "wk" in o:
            self.ingest_week(o["wk"], tick)
        if "rent" in o:
            self.rent_prices = o["rent"]
            bg = clip(0.3 + 0.6 * (self.heat - 0.75), 0.15, 0.85)
            reclaimed = {e["model"]: e["n"] for e in o.get("ev", ()) if e["type"] == "preempted"}
            for g in self.gpus:
                m = g["model"]
                if m in self.rent_prices:
                    base = g["price"] / self.rules["RENT_HOURS"]
                    pool = g["supply_q"] * self.rules["RENT_POOL_MULT"]
                    ours = max(0, o["gpu"].get(m, (0, 0, 0, 0))[3] - reclaimed.get(m, 0))
                    self.rival_cloud[m] = max(0.0, (self.rent_prices[m] / base - 1) / 2 - bg - ours / pool)
        for result in o.get("res", ()):
            if not result["ok"]:
                continue
            if result["act"] == "release" and self.publishing:
                self.pending_release = (result["live"], result["model"], *self.publishing)
                self.publishing = None
            elif result["act"] == "rent":
                self.lease_ids.append(result["id"])
        market_change = "wk" in o
        for e in o.get("ev", ()):
            kind = e["type"]
            if kind == "tech":
                tech = e["tech"]
                self.tech.add(tech)
                if tech.startswith("filter:"):
                    self.scale.filter(tech[7:], e["q"], e["c"])
            elif kind in ("release", "open_source"):
                m = e["model"]
                self.models[m["id"]] = dict(m)
                if m["owner"] == self.label:
                    self.opened = True
                    self.pending_release = None
                    market_change = True
                elif kind == "open_source":
                    if "wk" not in o:
                        for x in self.models.values():
                            if x["owner"] in ("N1", "N2"):
                                x["price"] *= 0.7
                    market_change = True
            elif kind == "audit_fail" and e["model"] in self.models:
                self.models[e["model"]]["pub"] = e["pub"]
                market_change = True
            elif kind == "preempted" and e["rent_id"] in self.lease_ids:
                self.lease_ids.remove(e["rent_id"])
                self.lease_until = tick
                self.spot_generation = None
                self.spot_cut = True
            elif kind == "done" and e["run"] in self.probes:
                self.samples.append((self.probes.pop(e["run"]), e["loss"]))
                if self.seed_checkpoint is None:
                    self.seed_checkpoint = (e["run"], e["ckpt"])
                if self.probe_active == e["run"]:
                    self.probe_active = None
        if not self.queue and not self.probe_active and not self.scale.ready:
            self.scale.calibrate(self.samples)
        if tick >= self.lease_until:
            self.lease_ids.clear()
            self.spot_generation = None
        return market_change

    def available(self, o, lease=True):
        gpu = o["gpu"]
        return [gpu[m][0] + (gpu[m][3] if lease else 0) if m in gpu else 0 for m in self.names]

    def installed(self, o):
        gpu = o["gpu"]
        counts = [sum(s["cards"].get(m, 0) for s in self.sites) for m in self.names]
        return [max(n, gpu[m][0] + gpu[m][1]) + gpu[m][2] if m in gpu else n
                for m, n in zip(self.names, counts)]

    def compute(self, cards):
        return sum(n * p for n, p in zip(cards, self.power))

    def infer_cost(self, n):
        factor = 0.6 if "infer_opt_2" in self.tech else 0.8 if "infer_opt_1" in self.tech else 1.0
        return self.rules["SK"] * n * factor

    def rivals(self, adjust=True):
        leaders = {}
        for m in self.models.values():
            label = m["owner"]
            if label == self.label:
                continue
            u = utility(m["pub"], m["price"])
            if label not in leaders or u > leaders[label][0]:
                leaders[label] = (u, m)
        weights = {label: math.exp(u) for label, (u, _) in leaders.items()}
        if MARKET_FEEDBACK and adjust and self.rival in weights:
            factor = 1.0 if self.rival_id is None else math.exp(self.rival_effect)
            weights[self.rival] *= factor
        return leaders, weights

    def offer(self, pub, n, capacity, rep, rivals, forecast_q=None):
        leaders, weights = rivals
        total = max(0.001, sum(weights.values()))
        opp = leaders.get(self.rival)
        displaced = 0.17 * weights[self.rival] / total * opp[1]["price"] if opp else 0.0
        q = self.market_q if forecast_q is None else forecast_q
        per = self.infer_cost(n)
        cost = 0.00042 * per
        strength = math.exp(6 * pub + rep)
        max_share = min(1.0, capacity / max(0.001, per * q) * 0.88)
        p = market_price(strength, total, cost, displaced, max_share=max_share)
        share = strength / (strength + total * p ** 1.5)
        margin = q * share * (p - cost) / 1000
        return p, share, max(0.0, margin)

    def market(self, a, o):
        if not self.opened:
            return
        tick = o["t"]
        own = [m for m in self.models.values() if m["owner"] == self.label and m["pub"] >= 0.152]
        if not own:
            return
        rivals = self.rivals()
        capacity = self.compute(self.available(o, False))
        offers = [(self.offer(m["pub"], m["N"], capacity, self.reputation, rivals), m) for m in own]
        offer, wanted = max(offers, key=lambda x: x[0][2] * (1.017 if x[1]["id"] == self.product else 1.0))
        desired = offer[0]
        anchor = next((m for m in own if m["id"] == self.product), None)
        if anchor is not None and anchor["price"] < 99.9:
            max_price = math.exp((6 * wanted["pub"] - utility(anchor["pub"], anchor["price"])) / 1.5) * 1.38
            desired = min(desired, max_price)
            if MARKET_FEEDBACK:
                # Migration lags quotes. Bound the immediate price change on
                # the existing customer base when a competitor is unstable.
                min_price = math.exp((6 * wanted["pub"] - utility(anchor["pub"], anchor["price"])) / 1.5) * 0.78
                desired = max(desired, min_price)
        desired = round(clip(desired, 1.0, 100.0), 4)
        day = (tick + 1) // self.rules["DAY"]
        previous = self.product
        for m in own:
            mid = m["id"]
            if self.last_price.get(mid) == day:
                continue
            price = desired if mid == wanted["id"] else 100.0
            if abs(m["price"] - price) >= max(0.015, m["price"] * 0.007):
                add(a, "price", {"model": mid, "value": price})
                self.last_price[mid] = day
                m["price"] = price
        self.product = wanted["id"]
        if previous != self.product:
            self.stats["market_switches"] = self.stats.get("market_switches", 0) + 1

    def service_need(self, o, ahead=0):
        tick = o["t"]
        candidates = [m for m in self.models.values() if m["owner"] == self.label and m["pub"] >= 0.152]
        if not candidates and not self.pending_release:
            return 0.0
        demand = o["api"][0]
        growth = 1.0
        for year, rate in enumerate((1.08, 1.05, 1.03)):
            dt = max(0, min(tick + ahead, 8760 * (year + 1)) - max(tick, 8760 * year))
            growth *= rate ** (dt / 730)
        if candidates:
            best = max(candidates, key=lambda m: utility(m["pub"], m["price"]))
            rival_weights = self.rivals()[1]
            u = math.exp(utility(best["pub"], best["price"]) + self.reputation)
            steady = u / (u + sum(rival_weights.values()))
            predicted = self.market_q * min(steady, self.share.get(self.label, 0.0) + 0.16)
            # Observed demand protects existing contracts, while the forward
            # estimate covers migration and demand changes at the next tick.
            need = self.infer_cost(best["N"]) * max(demand * 1.075, predicted * 1.13)
        else:
            need = 0.0
        if self.pending_release:
            live, _, n, pub, p = self.pending_release
            if live <= tick + 1 + ahead:
                if not candidates or utility(pub, p) > utility(best["pub"], best["price"]) - 0.06:
                    need = max(need, self.infer_cost(n) * max(demand * 1.09, self.market_q * 0.07))
        return need * growth

    def allocation(self, cards, service, data, interruption=None, owned=None):
        cards = cards.copy()
        sources = (cards,) if owned is None else (owned, cards)
        for source in sources:
            for i, p in enumerate(self.power):
                if service <= 0:
                    break
                reserved = min(source[i], cards[i], math.ceil(service / p))
                cards[i] -= reserved
                service -= reserved * p
        bc = self.scale.bc * (1 + data / 50) ** 0.4
        top = min(sum(cards), 14000)
        if not top:
            return [0] * len(cards), 1, 24, 0.0
        options = set(range(600, top, 600)) | {top}
        accumulated = 0
        for count in reversed(cards):
            accumulated += count
            if 0 < accumulated < top:
                options.add(accumulated)
        best = (0.0, [0] * len(cards), 1, 24)
        for n in sorted(options):
            plan = [0] * len(cards)
            left = n
            for i in reversed(range(len(cards))):
                plan[i] = min(left, cards[i])
                left -= plan[i]
                if left <= 0:
                    break
            b = (n + 1) // 2
            hazard = interruption[1] if interruption and plan[interruption[0]] else 0.0
            k, fraction = checkpoint(n, self.rules["MTBF"], self.rules["CKPT_COST"], self.rules["RESTART"], hazard)
            quality = min(1.0, 0.5 + 0.5 * bc / b)
            speed = self.compute(plan) * quality * fraction
            if speed > best[0]:
                best = speed, plan, b, k
        speed, plan, b, k = best
        return plan, b, k, speed

    def cloud_fraction(self, i):
        bg = clip(0.3 + 0.6 * (self.heat - 0.75), 0.15, 0.85)
        return clip(bg + self.rival_cloud.get(self.names[i], 0.0), bg, 1.0)

    def preemption(self, i, n):
        pool = self.gpus[i]["supply_q"] * self.rules["RENT_POOL_MULT"]
        return 0.02 + 0.08 * min(1.0, self.cloud_fraction(i) + n / pool)

    def use_spot(self, tick, owned, service):
        return SPOT_TRAINING and tick < self.end - 320 and service <= 0.90 * self.compute(owned)

    def lease_plan(self, tick, phase, cash, cards, service, spot=False):
        count = [0] * len(cards)
        if phase >= len(TRAIN_FLOOR) or cash < 47.0:
            return count
        horizon = max(840, min(2500, self.deadlines[min(phase, len(self.deadlines) - 1)] - tick))
        budget = min(MAX_LEASE_RATE[phase], (cash - 43) / horizon + 0.20 * self.revenue)
        target = TRAIN_FLOOR[phase]
        if phase == 1 and tick < 2190:
            target = 3900
        if spot and tick < 2190:
            target *= SPOT_HEADROOM
        needed = target + service - self.compute(cards)
        if needed <= 350:
            return count
        if spot:
            budget /= self.rules["SPOT_MULT"]
        best_spot = (0.0, 0, 0)
        for i in reversed(range(len(cards))):
            g = self.gpus[i]
            if tick // self.rules["QUARTER"] < g["launch_q"]:
                continue
            cap = g["supply_q"] * self.rules["RENT_POOL_MULT"]
            base = g["price"] / self.rules["RENT_HOURS"]
            u = self.cloud_fraction(i)
            room = int(cap * max(0.0, 1 - u) * 0.90)
            n = min(room, math.ceil(needed / g["power"]), int(budget / (base * (1 + 2 * min(1, u + 0.24)))))
            if n < 64:
                continue
            if spot:
                # A single lease avoids compounding independent interruptions.
                score = n * g["power"] * (1 - self.preemption(i, n)) ** 3
                if score > best_spot[0]:
                    best_spot = (score, i, n)
                continue
            count[i] = n
            needed -= n * g["power"]
            budget -= n * base * (1 + 2 * min(1, u + n / cap))
            if needed < 64 * g["power"] or budget <= 0:
                break
        if spot:
            _, i, n = best_spot
            count[i] = n
        return count

    def forecast(self, o, deadline, phase, data, include_future, long_run=False):
        tick = o["t"]
        hours = max(1, deadline - tick)
        own = self.available(o, False)
        installed = self.installed(o)
        estimate = 0.0
        slices = min(15 if long_run else 9, max(1, math.ceil(hours / 290)))
        for j in range(slices):
            dt = hours * (j + 0.5) / slices
            when = tick + dt
            cards = [max(n, int(0.98 * m)) if dt >= 360 else n for n, m in zip(own, installed)]
            for arrives, m, amount in self.deliveries:
                if arrives <= when:
                    cards[self.names.index(m)] += amount
            if include_future:
                for i, g in enumerate(self.gpus):
                    launch = 2190 * (g["launch_q"] - (1 if i >= 2 and "early_supply" in self.tech else 0))
                    horizon = min(when - 1200, LAST_BUY[i]) - max(tick, launch)
                    if horizon <= 0 or i == 0 and o["cash"] < 65:
                        continue
                    weekly = (135, 135, 175, 165, 125)[i]
                    cards[i] += min(max(0, OWN_TARGET[i] - cards[i]), int(horizon * weekly / 168))
            serve = self.service_need(o, dt)
            lease_phase = min(len(TRAIN_FLOOR) - 1, bisect_right(LEASE_MILESTONES, when)) if long_run else phase
            spot = self.use_spot(int(when), cards, serve)
            lease = self.lease_plan(int(when), lease_phase, o["cash"], cards, serve, spot=spot)
            total = [n + r for n, r in zip(cards, lease)]
            hazard = next(((i, self.preemption(i, n)) for i, n in enumerate(lease) if n), None) if spot else None
            with_rent = self.allocation(total, serve, data, hazard, cards if hazard else None)[3]
            estimate += max(with_rent, self.allocation(cards, serve, data)[3]) if hazard else with_rent
        return hours * estimate / slices

    def data_plan(self, o, a, tokens):
        cash = o["cash"]
        desired = min(16000, max(50, tokens * 0.13))
        current = self.scale.size[8]
        rivals = [m for m in self.models.values() if m["owner"] in ("N1", "N2", "OPEN")]
        if desired > current * 1.28 and rivals and cash > 40:
            teacher = max(rivals, key=lambda m: 0.8 * m["pub"] - 0.0055 * m["price"] + (0.09 if m["owner"] == "OPEN" else 0.0))
            price = 0 if teacher["owner"] == "OPEN" else teacher["price"] / 1000
            amount = desired * (2.0 if price == 0 else 1.0) - current
            if price:
                amount = min(amount, min(34.0, 0.085 * (cash - 35)) / price)
            if amount > 8:
                add(a, "distill", {"model": teacher["id"], "tokens_b": amount})
                self.scale.add(8, amount, 0.5 + 0.8 * teacher["pub"])
        if "synth" in self.tech and cash > 270 and o["t"] < self.end - 600:
            models = [m for m in self.models.values() if m["owner"] == self.label]
            if models:
                best = max(models, key=lambda m: m["pub"])
                unit = best["N"] * 100 * self.rent_prices.get("G1", 0.000015)
                desired = min(1250, tokens * 0.15)
                amount = min(desired - self.scale.size[7], min(45.0, 0.05 * cash) / max(unit, 0.0001))
                if amount > 85:
                    add(a, "synth", {"tokens_b": amount})
                    self.synth_inflight.append((o["t"] + 25, amount, 0.6 + 0.6 * max(0.0, best["pub"] - 0.035)))

    def start_run(self, o, a):
        tick = o["t"]
        if self.phase >= len(self.deadlines) or tick >= self.end - 2:
            return
        deadline = self.deadlines[self.phase]
        if deadline < tick + 180 and self.phase + 1 < len(self.deadlines):
            self.phase += 1
            deadline = self.deadlines[self.phase]
        algo = sum(f"algo_eff_{j}" in self.tech for j in (1, 2, 3))
        mult = (1.0, 1.15, 1.30, 1.50)[algo]
        continuous = CONTINUOUS_TRAINING and self.phase == 2 and len(self.deadlines) >= 5
        long_run = CONTINUOUS_TRAINING and deadline - tick > 5600
        budget = 0.96 * self.forecast(o, deadline, self.phase, (350, 950, 2000, 3700, 5000, 6200, 8500)[self.phase],
                                      True, long_run=long_run)
        if budget < 900:
            return
        if continuous:
            budget *= 0.78
            far_budget = 0.66 * self.forecast(o, self.deadlines[-2], self.phase, 5000, True, long_run=True)
            near_budget = 0.72 * self.forecast(o, self.deadlines[-3], self.phase, 3100, True, long_run=True)
        self.data_plan(o, a, math.sqrt(budget * 55 / self.rules["KC"]))
        base_n = math.sqrt(budget / (self.rules["KC"] * 48))
        rivals = self.rivals()
        cap = self.compute(self.available(o, False)) + max(0.0, 0.42 * self.compute([n for n in self.available(o)]))
        best = None
        for k in range(-5, 11 if continuous else 7):
            n = clip(base_n * 1.17 ** k, 0.5, 4800)
            d = clip(budget / (self.rules["KC"] * n), 0.01, 100000)
            mix = self.scale.mix(d)
            score = self.scale.score(n * mult, mix, anneal=0.019 if continuous else 0.03)
            pub = score + min(0.05, sum(c * x for x, c in zip(mix, self.scale.c)) / d)
            p, _, margin = self.offer(pub, n, cap, self.reputation, rivals)
            w = 0.048 if self.phase < len(self.deadlines) - 1 else 0.019
            criterion = score + w * math.log(max(0.0008, margin))
            if continuous:
                middle_d = near_budget / (n * self.rules["KC"])
                last_d = far_budget / (n * self.rules["KC"])
                c_mid = self.scale.score(n * mult, self.scale.mix(middle_d), anneal=0.019)
                c_last = self.scale.score(n * mult, self.scale.mix(last_d), anneal=0.019)
                criterion = 0.22 * score + 0.27 * c_mid + 0.51 * c_last + 0.027 * math.log(max(0.0008, margin))
            if best is None or criterion > best[0]:
                best = criterion, n, d, mix, score, pub, p
        _, n, tokens, mix, score, pub, price = best
        name = f"generation{self.phase + 1}"
        self.run = {"name": name, "t": tick, "deadline": deadline, "N": n, "D": tokens, "mult": mult,
                    "mix": [x / tokens for x in mix], "pub": pub, "C": score, "price": price,
                    "target": min(1e6, 1.70 * tokens + 10), "committed": False,
                    "cards": None, "batch": 1, "interval": 24, "rate": self.scale.eta,
                    "continuous": continuous, "segments": [(0.0, [x / tokens for x in mix])],
                    "next_data": tick + 800, "data_sizes": self.scale.size.copy()}
        if continuous:
            self.run["target"] = 1e6
        self.stats[name] = (tick, round(n, 2), round(tokens, 2), round(score, 4), round(budget))
        self.training_cards(o, a, 0.0, start=True)
        if continuous or budget > 0.85 * self.rules["REG_COMPUTE"]:
            add(a, "audit_request", {"run": name})

    def control(self, a, op, arg=None):
        command = {"name": self.run["name"], "op": op}
        if arg is not None:
            command["arg"] = arg
        add(a, "run_ctl", command)

    def training_cards(self, o, a, data, start=False, lease=None):
        r = self.run
        use_lease = o["t"] + 1 < self.lease_until
        owned = self.available(o, False)
        cards = self.available(o, use_lease) if lease is None else [x + y for x, y in zip(owned, lease)]
        i = self.spot_generation
        hazard = (i, self.preemption(i, cards[i] - owned[i])) if i is not None and cards[i] > owned[i] else None
        need = self.service_need(o)
        plan, batch, interval, speed = self.allocation(cards, need, data, hazard, owned if hazard else None)
        if hazard:
            own_plan, own_batch, own_interval, own_speed = self.allocation(owned, need, data)
            if own_speed > speed:
                plan, batch, interval = own_plan, own_batch, own_interval
        requests = {m: n for m, n in zip(self.names, plan) if n}
        if start:
            add(a, "run", {"name": r["name"], "params_b": r["N"], "tokens_b": r["target"],
                           "lr": r["rate"] * r["N"] ** -0.3, "ckpt_every": interval, "batch": batch,
                           "gpus": requests, "sched": "cosine" if r["continuous"] else "wsd",
                           "mix": {d: w for d, w in zip(POOLS, r["mix"]) if w > 0}})
        else:
            if requests != r["cards"]:
                self.control(a, "set_gpus", requests)
            if abs(batch - r["batch"]) > max(1, 0.025 * r["batch"]):
                self.control(a, "set_batch", batch)
            else:
                batch = r["batch"]
            if interval != r["interval"]:
                self.control(a, "set_ckpt", interval)
        r.update(cards=requests, batch=batch, interval=interval)

    def used_data(self, data):
        r = self.run
        rows = r["segments"]
        used = [0.0] * len(POOLS)
        for i, (start, mix) in enumerate(rows):
            if start >= data:
                break
            stop = min(data, rows[i + 1][0]) if i + 1 < len(rows) else data
            for j, fraction in enumerate(mix):
                used[j] += fraction * (stop - start)
        return used

    def publish(self, o, a, d, ckpt, finish=True, cosine_target=None):
        r = self.run
        counts = self.used_data(d)
        anneal = (0.02 * min(1.0, d / (cosine_target or r["target"])) ** 2 if r["continuous"] else
                  0.03 if d >= r["target"] - 0.02 else 0.012)
        c = self.scale.score(r["N"] * r["mult"], counts, anneal=anneal)
        pub = c + min(0.049, sum(w * x for w, x in zip(counts, self.scale.c)) / max(0.001, d))
        rivals = self.rivals()
        capacity = self.compute(self.available(o, False))
        price, _, value = self.offer(pub, r["N"], capacity, self.reputation, rivals)
        current = self.models.get(self.product)
        if current:
            _, _, incumbent = self.offer(current["pub"], current["N"], capacity, self.reputation, rivals)
            if value < 0.97 * incumbent:
                price = 100.0
            else:
                old_u = utility(current["pub"], current["price"])
                # The incumbent stays in the market through the launch delay.
                price = min(price, max(1.0, math.exp((6 * pub - old_u + 0.025) / 1.5)))
        if ckpt and o["t"] <= self.end:
            add(a, "release", {"run": r["name"], "ckpt": ckpt, "price": round(price, 4)})
            self.publishing = (r["N"], pub, price)
        self.phase += 1
        if finish:
            self.run = None
        else:
            r.update(deadline=self.deadlines[self.phase], extend=True)

    def adapt_mix(self, o, a, data, speed, left):
        tick = o["t"]
        r = self.run
        if tick % 168 == 0 and "curriculum" in self.tech and left > 300 and data > 120:
            if tick >= r["next_data"]:
                self.data_plan(o, a, data + max(500, (self.end - tick) * max(speed, 0.4) * 0.60))
                r["next_data"] = tick + 1344
            delta = max(abs(u - v) / max(100.0, v) for u, v in zip(self.scale.size, r["data_sizes"]))
            if delta > 0.08 or r.get("last_mix_day", -3000) + 840 < tick:
                used = self.used_data(data)
                future = data + clip(max(speed, 0.3) * min(4200, self.end - tick) * 0.90, 150.0, 6800.0)
                mix = self.scale.mix(future, used)
                before = [s + (future - data) * w for s, w in zip(used, r["mix"])]
                value = self.scale.score(r["N"] * r["mult"], mix) - self.scale.score(r["N"] * r["mult"], before)
                if value > 0.00025:
                    next_mix = [max(0.0, (x - s) / (future - data)) for x, s in zip(mix, used)]
                    self.control(a, "set_mix", {d: w for d, w in zip(POOLS, next_mix) if w > 0})
                    # A coincident rollback can cross a previous mix change.
                    r["segments"] = [(x, w) for x, w in r["segments"] if x < data] + [(data, next_mix)]
                    r["mix"] = next_mix
                r["data_sizes"] = self.scale.size.copy()
                r["last_mix_day"] = tick

    def continuous(self, o, a, data, target, speed, ckpt, status):
        tick = o["t"]
        r = self.run
        if r.pop("extend", False):
            r["extend"] = data >= 0.98 * target
            goal = min(1e6, target * 1.045) if r["extend"] else 1e6
            self.control(a, "set_tokens", goal)
            r["target"] = goal
            return
        if status != "running":
            return
        left = r["deadline"] - tick
        self.adapt_mix(o, a, data, speed, left)
        if not ckpt or data <= 1.0:
            return
        final = self.phase + 1 == len(self.deadlines)
        if tick % 24 == 23 and 140 < left < 600:
            expected = self.forecast(o, r["deadline"], self.phase, data, False) / (r["N"] * self.rules["KC"])
            goal = max(data / 0.94, data + expected * 1.06)
            if goal > data + 0.05 and (goal < target or data < 0.975 * target):
                self.control(a, "set_tokens", goal)
                r["target"] = goal
                return
        # Checkpoints are short with a large fleet. Stay below the 98% guard
        # on an intermediate release, then extend at the following tick.
        if (left <= 156 and data >= 0.958 * target) or left <= 7 or data > 0.976 * target:
            current = max(data / (0.969 if not final else 0.995), data + max(0.02, 5 * speed))
            if current > target and data >= 0.979 * target:
                current = min(current, target * 1.04)
            if current > data:
                self.control(a, "set_tokens", current)
                r["target"] = current
            if final:
                self.control(a, "stop")
            self.publish(o, a, data, ckpt, finish=final, cosine_target=current)

    def train(self, o, a, market_change):
        tick = o["t"]
        if not self.scale.ready:
            if self.probe_active is None and self.queue and tick < self.end - 400:
                spec = self.queue.popleft()
                _, _, n, d, lr, mix = spec
                name = "probe" + str(len(self.samples) + len(self.probes))
                self.probes[name] = spec
                self.probe_active = name
                add(a, "run", {"name": name, "params_b": n, "tokens_b": d, "lr": lr * n ** -0.3,
                               "batch": 750, "ckpt_every": 3, "sched": "const", "mix": mix})
            elif self.probe_active:
                state = next((row for row in o["runs"] if row[0] == self.probe_active), None)
                if state and 0 < state[4] and state[1] == "running":
                    self.scale.observe_batch(state[7], 750, max(0.0, state[2] - state[4]), state[5])
            return
        if self.run is None:
            if "algo_eff_1" in self.tech or tick >= min(490, max(40, self.end / 4)):
                self.start_run(o, a)
            return
        r = self.run
        state = next((row for row in o["runs"] if row[0] == r["name"]), None)
        if not state:
            return
        _, status, data, target, speed, eff, ckpt, cards = state
        if DATA_VALUE:
            delta = data - r.get("data_seen", data)
            r["progress_rate"] = max(0.0, r.get("progress_rate", 0.0) * 0.997 + delta * 0.003)
            r["data_seen"] = data
        now = o.get("ev", ())
        for e in now:
            if e.get("run") != r["name"]:
                continue
            if e["type"] in ("spike", "diverged") and status != "done":
                r["rate"] *= 0.87
                self.scale.eta = min(self.scale.eta, r["rate"])
                if ckpt:
                    self.control(a, "rollback", ckpt)
                self.control(a, "set_lr", r["rate"] * r["N"] ** -0.3)
            elif e["type"] == "slow_node" and status == "running":
                self.control(a, "diagnose")
        if status == "done":
            self.publish(o, a, data, ckpt)
            return
        if tick >= min(self.end, r["deadline"] + 70) and ckpt:
            self.control(a, "stop")
            self.publish(o, a, data, ckpt)
            return
        if tick % 24 == 23 and speed > 0 and not any(e["type"] == "slow_node" for e in now):
            self.scale.observe_batch(cards, r["batch"], max(0.0, data - speed), eff)
        hour_change = (tick % 24 == 23 or market_change or tick + 1 == self.lease_until or self.spot_cut
                       or any(e["type"] in ("delivered", "curtail", "site_ready", "review_done") for e in now)
                       or any(x["act"] == "rent" and x["ok"] for x in o.get("res", ())))
        if hour_change:
            self.training_cards(o, a, data)
        if r["continuous"]:
            self.continuous(o, a, data, target, speed, ckpt, status)
            return
        remains = r["deadline"] - tick
        if tick % 24 == 23 and status == "running" and (data >= 0.50 * r["D"] or remains <= 440):
            budget = self.forecast(o, max(tick + 3, r["deadline"]), self.phase, data * 1.05, False)
            possible = data + budget / (r["N"] * self.rules["KC"])
            if not r["committed"] and (data > 0.810 * possible or remains <= 89):
                goal = max(data + 0.009, data + 0.91 * (possible - data))
                if goal > target and data >= 0.847 * target:
                    goal = target
                if abs(goal - target) > 0.008:
                    self.control(a, "set_tokens", goal)
                r.update(target=goal, committed=True)
            elif r["committed"] and remains <= 66 and target > possible and target > data + 0.025:
                goal = min(target, max(data + 0.012, data + 0.87 * (possible - data)))
                if target - goal > 0.009:
                    self.control(a, "set_tokens", goal)
                    r["target"] = goal

    def hires(self, a, o):
        if self.researching is None:
            if self.staff:
                a["fire"] = [row[0] for row in self.staff]
            return
        points = sum(x[1] for x in self.staff)
        if o["t"] > 3000 or points >= 157 or o["cash"] < 40:
            return
        people = []
        for person in self.week["talent"]:
            ask = person["ask"]
            values = [ab for ab in range(person["lo"], min(5, person["hi"]) + 1)
                      if 0.00009 * (0.5 + 0.5 * ab) - 0.0000005 <= ask
                      <= 0.00012 * (0.5 + 0.5 * ab) + 0.0000005]
            ab = sum(values) / len(values) if values else person["lo"]
            people.append((ab, ask, person["id"]))
        for ab, ask, person_id in sorted(people, key=lambda x: (-x[0], x[1]))[:13]:
            if points >= 163:
                break
            if ab < 2.0:
                break
            add(a, "hire", {"cand": person_id, "salary": ask * 1.304 + 0.00000001})
            points += ab

    def buy_data(self, a, o, available):
        t = o["t"]
        row = self.run
        if row is None or not self.week["deals"] or not 4450 < t < self.end - 500:
            return
        available = min(available * 0.30, 36.0 + 120 * self.revenue)
        if available < 3 or self.revenue < 0.018 or not row["continuous"]:
            return
        data = row.get("data_seen", 0.0)
        rate = row.get("progress_rate", 0.0)
        remaining = clip(rate * min(self.end - t, 3600), 1100.0, 12000.0)
        mix = self.used_data(data)
        for j, weight in enumerate(row["mix"]):
            mix[j] += remaining * weight
        size = data + remaining
        n = row["N"] * row["mult"]
        base_score = self.scale.score(n, mix, anneal=0.019)
        base_dirt = sum(amount * c for amount, c in zip(mix, self.scale.c)) / size
        revenue_value = (min(self.rules["GM_WINDOW"], self.end - t) * self.rules["END_GM_MULT"]
                         + min(4400, self.end - t)) * self.revenue
        deals = []
        for deal in self.week["deals"]:
            j = POOLS.index(deal["domain"])
            u, q = self.scale.size[j], self.scale.q[j]
            amount = deal["tokens_b"]
            quality = clip(deal["q_hint"], 0.6, 1.5)
            self.scale.size[j] = u + amount
            # Older samples retain their quality. Only new samples receive
            # the new quality average, while the pool width affects both.
            updated_q = (u * q + amount * quality) / (u + amount)
            share = remaining * row["mix"][j] / max(1.0, mix[j])
            self.scale.q[j] = q + share * (updated_q - q)
            new_score = self.scale.score(n, mix, anneal=0.019)
            self.scale.size[j], self.scale.q[j] = u, q
            c = self.scale.c[j]
            new_c = 0.020 if j in self.scale.filtered else 0.040
            new_dirt = base_dirt + remaining * row["mix"][j] * amount * (new_c - c) / (size * (u + amount))
            gain_c = new_score - base_score
            gain_pub = gain_c + min(0.046, new_dirt) - min(0.046, base_dirt)
            value = (300 * gain_c + revenue_value * math.expm1(4 * gain_pub)) * 0.55
            if value > 1.28 * deal["reserve"]:
                deals.append((value, deal))
        for value, deal in sorted(deals, key=lambda choice: -choice[0]):
            reserve = deal["reserve"]
            price = round(min(reserve * 2.06, max(reserve * 1.06, value * 0.65)) + 0.001, 3)
            if price <= available:
                add(a, "bid_data", {"deal": deal["id"], "price": price})
                available -= price

    def capital(self, a, o):
        t, cash = o["t"], o["cash"]
        quarter = (t + 1) // self.rules["QUARTER"]
        reserve = 53.0 if t < 3800 else 70.0 if t < 7400 else 95.0
        inst = self.installed(o)
        incoming = inst.copy()
        for _, m, n in self.deliveries:
            incoming[self.names.index(m)] += n
        available = max(0.0, cash - reserve)
        current_mw = sum(s["mw"] + s["pend_mw"] for s in self.sites)
        pue = self.rules["PUE1"] if "cooling" in self.tech else self.rules["PUE0"]
        mw = sum(n * g["kw"] * pue / 1000 for n, g in zip(incoming, self.gpus))
        if t < 23600 and current_mw > 0 and (mw > 0.69 * current_mw or t >= 2200 and current_mw < 5):
            site0 = self.sites[0]
            extra = min(self.regions[0]["cap_mw"] - site0["mw"] - site0["pend_mw"], 3.5)
            if current_mw < 4.1 and extra >= 1.0 and available > extra * 2.0 + 5:
                add(a, "expand_site", {"site": site0["id"], "mw": extra})
                current_mw += extra
                available -= extra * 2.0
            elif len(self.sites) < 8:
                region = max(self.regions, key=lambda r: r["cap_mw"] / (r["build_cost"] + 14)
                             - 0.006 * r["build_weeks"] - 0.025 * r["reg"] - 65 * r["price"]
                             - 0.11 * sum(s["region"] == r["id"] for s in self.sites))
                if available > region["build_cost"] + 10:
                    add(a, "build_site", {"region": region["id"]})
                    current_mw += region["cap_mw"]
                    available -= region["build_cost"]
        for i in reversed(range(len(self.names))):
            g = self.gpus[i]
            name = g["model"]
            offer = self.week["offer"].get(name)
            if not offer or not offer["lots"] or t >= min(LAST_BUY[i], self.end - 1150):
                continue
            if offer["early"] and "early_supply" not in self.tech:
                continue
            if i == 0 and incoming[i] >= 1500 and t < 900:
                continue
            target = OWN_TARGET[i]
            if i == 0 and t > 2200:
                target = 1500
            if incoming[i] >= target or mw > current_mw * 0.96 + (0.9 if i < 2 else 1.7):
                continue
            factor = 1.47 if i < 2 and t < 5800 else 1.62
            if available < 75 and i <= 1:
                factor = 1.32
            if offer["early"]:
                factor = 1.33
            elif ADAPT_AUCTIONS:
                factor = max(factor, self.auction_need[i])
                if i == 0 and t < 1200:
                    factor = min(1.85, factor)
            price = round(max(offer["reserve"] * 1.011, g["price"] * self.heat * factor), 6)
            cost = price * self.rules["LOT"]
            lots = min(offer["lots"], (target - incoming[i] + 255) // 256, int(available / cost))
            if i == 0 and t < 1150:
                lots = min(1, lots)
            if lots > 0:
                add(a, "bid_gpu", {"model": name, "lots": lots, "price": price})
                self.auction_bid[name] = (factor, lots)
                available -= cost * lots
                mw += lots * 256 * g["kw"] * pue / 1000
        if (FINANCE and quarter not in self.raised and o["eq"] >= 0.89 and 2350 <= t <= 12000
                and cash < reserve + 49 and self.revenue >= 0.024 and mw < current_mw + 8):
            estimated = 21.0 * self.trailing_sum + cash
            amount = min(145.0 if t < 7000 else 180.0, 0.082 * estimated)
            if amount > 36:
                add(a, "raise", {"amount": amount})
                self.raised.add(quarter)
        if DATA_VALUE and self.phase >= 2:
            self.buy_data(a, o, available)
            return
        data_cash = min(available * 0.28, max(0.0, self.revenue * 168 * 0.45), 43.0)
        if t < 21800 and data_cash > 2.5:
            rows = []
            d_forecast = max(1500, (self.run["D"] if self.run else 2400) * 1.40)
            for d in self.week["deals"]:
                j = DOMAINS.index(d["domain"])
                s = d_forecast * (self.run["mix"][j] if self.run else 0.15)
                u = self.scale.size[j]
                q = self.scale.q[j]
                added = d["tokens_b"]
                eq = effective(s, 4 * (u + added)) * (u * q + added * d["q_hint"]) / (u + added)
                gain = eq - q * effective(s, 4 * u)
                score = gain / max(1.0, d["reserve"]) / (0.27 + (u / 650) ** 0.6)
                if score > 0.55:
                    rows.append((score, d))
            for score, d in sorted(rows, key=lambda x: -x[0]):
                price = d["reserve"] * (1.16 if score < 2.1 else 1.65 if score < 4.1 else 2.12) + 0.001
                if price <= data_cash:
                    add(a, "bid_data", {"deal": d["id"], "price": round(price, 3)})
                    data_cash -= price

    def rents(self, o, a):
        tick = o["t"]
        r = self.run
        state = next((s for s in o["runs"] if r and s[0] == r["name"]), None)
        review = SPOT_TRAINING and (bool(a.get("audit_request")) or state and state[1] == "review")
        if r is None or review:
            if self.lease_ids:
                a["end_rent"] = self.lease_ids.copy()
                self.lease_ids.clear()
                self.lease_until = tick + 1
                self.spot_generation = None
            return
        if tick < self.lease_until or (not self.spot_cut and any(v[3] for v in o["gpu"].values())):
            return
        if any(x["act"] == "rent" and not x["ok"] for x in o.get("res", ())):
            self.lease_until = tick + 24
            return
        if tick % 24 != 1 and self.run["t"] != tick and tick != self.lease_until:
            return
        if tick > min(self.end, self.run["deadline"] + 48):
            return
        own = self.available(o, False)
        service = self.service_need(o)
        spot = self.use_spot(tick + 1, own, service)
        counts = self.lease_plan(tick + 1, self.phase, o["cash"], own, service, spot=spot)
        if not any(counts):
            return
        until = max(24, min(168, self.run["deadline"] + 35 - tick))
        progress = state[2] if state else 0.0
        for i, (m, n) in enumerate(zip(self.names, counts)):
            if n > 0:
                add(a, "rent", {"model": m, "n": n, "kind": "spot" if spot else "ondemand", "ticks": until})
                if spot:
                    self.spot_generation = i
        self.lease_until = tick + 1 + until
        if SPOT_TRAINING:
            self.training_cards(o, a, progress, lease=counts)

    def seed_corpus(self, action, o):
        if not BOOTSTRAP_SYNTH or self.corpus_sent or self.phase > 1:
            return
        if not self.seed_sent and self.seed_checkpoint:
            name, ckpt = self.seed_checkpoint
            add(action, "release", {"run": name, "ckpt": ckpt, "price": 100.0})
            self.seed_sent = True
        if "synth" in self.tech and self.opened and self.phase == 0 and o["cash"] >= 14:
            if not any(m["pub"] > 0.15 for m in self.models.values() if m["owner"] == self.label):
                amount = 50000
                add(action, "synth", {"tokens_b": amount})
                self.synth_inflight.append((o["t"] + 25, amount, 0.60))
                self.corpus_sent = True

    def step(self, o):
        if o["bk"]:
            return {}
        action = {}
        market_change = self.observe(o)
        research = next((r for r in self.research_order if r not in self.tech), None)
        if research != self.researching:
            self.researching = research
            if research:
                action["research"] = [{"tech": research, "share": 1}]
        if market_change:
            self.market(action, o)
        if "wk" in o:
            self.hires(action, o)
            self.capital(action, o)
        self.seed_corpus(action, o)
        self.train(o, action, market_change)
        self.rents(o, action)
        return action


def make_bot(init):
    return Frontier(init)


def main():
    read = sys.stdin.buffer.readline
    write = sys.stdout.write
    flush = sys.stdout.flush
    line = read()
    if not line:
        return
    bot = make_bot(json.loads(line))
    write("{}\n")
    flush()
    for line in sys.stdin.buffer:
        message = json.loads(line)
        if message.get("type") == "end":
            write("{}\n")
            flush()
            return
        action = bot.step(message)
        write(json.dumps(action, separators=(",", ":"), allow_nan=False) + "\n" if action else "{}\n")
        flush()


if __name__ == "__main__":
    main()
